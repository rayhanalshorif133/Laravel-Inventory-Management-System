-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: fashol_db
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `smg_manager_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,'Default Category','2021-08-06 12:37:48','2021-08-06 12:37:48'),(2,4,'Vagitables','2021-08-06 13:31:59','2021-08-06 13:31:59'),(3,4,'Fruits','2021-08-06 14:46:31','2021-08-06 14:46:41');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_account_logs`
--

DROP TABLE IF EXISTS `customer_account_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_account_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `payment` decimal(8,2) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_account_logs`
--

LOCK TABLES `customer_account_logs` WRITE;
/*!40000 ALTER TABLE `customer_account_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_account_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sales_executive_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` tinyint NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'F_CU6173',1,1,'Default Customer','015321654','aaa','bbb','customer_nid_12_Aug_12_03.jpg',1,NULL,'2021-08-06 12:37:44','2021-08-06 12:37:44'),(2,'F_CU3258',1,2,'Customer-1','01797840512','dhanmondi-1',NULL,'customer_nid_19_Aug_19_02.jpg',1,NULL,'2021-08-06 13:31:02','2021-08-06 16:52:32'),(3,'F_CU9645',1,3,'Customer-2','01797840511','dhanmondi-1',NULL,'customer_nid_22_Aug_22_03.png',1,NULL,'2021-08-06 16:48:03','2021-08-06 16:52:34');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_for_customers`
--

DROP TABLE IF EXISTS `delivery_for_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_for_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  `sales_executive_id` bigint unsigned NOT NULL,
  `product_quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_cost` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_for_customers`
--

LOCK TABLES `delivery_for_customers` WRITE;
/*!40000 ALTER TABLE `delivery_for_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_for_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_teams`
--

DROP TABLE IF EXISTS `delivery_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_teams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `smg_manager_id` bigint unsigned NOT NULL DEFAULT '1',
  `zone_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_teams`
--

LOCK TABLES `delivery_teams` WRITE;
/*!40000 ALTER TABLE `delivery_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2011_07_17_164841_create_permission_tables',1),(2,'2012_07_16_104654_create_zones_table',1),(3,'2012_07_17_132919_create_users_table',1),(4,'2016_06_01_000001_create_oauth_auth_codes_table',1),(5,'2016_06_01_000002_create_oauth_access_tokens_table',1),(6,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(7,'2016_06_01_000004_create_oauth_clients_table',1),(8,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(10,'2019_08_19_000000_create_failed_jobs_table',1),(11,'2021_06_22_105319_create_customers_table',1),(12,'2021_06_22_112907_create_categories_table',1),(14,'2019_07_14_122229_create_units_table',2),(15,'2021_06_22_113133_create_products_table',2),(16,'2021_06_23_060400_create_orders_table',2),(17,'2021_06_23_061510_create_suppliers_table',2),(18,'2021_06_23_062502_create_supplier_histories_table',2),(19,'2021_06_23_063257_create_order_lists_table',2),(20,'2021_06_23_063829_create_delivery_for_customers_table',2),(21,'2021_06_23_065001_create_customer_account_logs_table',2),(22,'2021_07_09_101536_create_notifications_table',2),(23,'2021_07_12_120855_create_prices_table',2),(24,'2021_07_29_132159_create_delivery_teams_table',2),(25,'2021_08_03_132233_create_requirements_table',2),(26,'2021_08_04_125742_create_payment_histories_table',2),(27,'2021_08_04_163441_create_total_requirements_table',2),(28,'2021_08_05_151436_create_packagings_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(6,'App\\Models\\User',2),(3,'App\\Models\\User',3),(8,'App\\Models\\User',4),(7,'App\\Models\\User',5),(8,'App\\Models\\User',6),(3,'App\\Models\\User',7);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('056360b4-5c6f-4a37-9e54-e208cfbd44f4','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":8}}',NULL,'2021-08-06 18:49:45','2021-08-06 18:49:45'),('0ba424b0-a184-4149-b36f-9100606ae9ef','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"zone_id\":2,\"product_id\":3,\"unit_id\":1,\"variant\":\"\\u09ae\\u09be\\u099d\\u09be\\u09b0\\u09bf\",\"required_qty\":\"3\",\"status\":\"waiting\",\"updated_at\":\"2021-08-06T19:11:21.000000Z\",\"created_at\":\"2021-08-06T19:11:21.000000Z\",\"id\":14}}',NULL,'2021-08-06 19:11:22','2021-08-06 19:11:22'),('18adc59b-7424-458e-b5bb-81960cb24bb7','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"id\":7,\"zone_id\":2,\"product_id\":2,\"unit_id\":\"1\",\"variant\":\"\\u099b\\u09cb\\u099f\",\"required_qty\":46,\"sypplied_qty\":null,\"status\":\"waiting\",\"note\":null,\"created_at\":\"2021-08-06T18:42:46.000000Z\",\"updated_at\":\"2021-08-06T19:07:05.000000Z\"}}',NULL,'2021-08-06 19:07:05','2021-08-06 19:07:05'),('2e59bd41-7f71-451b-8aa4-70e75db5cacf','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"zone_id\":2,\"product_id\":2,\"unit_id\":1,\"variant\":\"\\u09ac\\u09dc\",\"required_qty\":\"3\",\"status\":\"waiting\",\"updated_at\":\"2021-08-06T18:50:14.000000Z\",\"created_at\":\"2021-08-06T18:50:14.000000Z\",\"id\":10}}',NULL,'2021-08-06 18:50:14','2021-08-06 18:50:14'),('46e42cae-0baf-43e9-a0e2-842b574464f5','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":4}}',NULL,'2021-08-06 14:48:32','2021-08-06 14:48:32'),('49b67cfc-3fc8-4681-9b4d-997ec5ac26d7','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"zone_id\":2,\"product_id\":2,\"unit_id\":1,\"variant\":\"\\u099b\\u09cb\\u099f\",\"required_qty\":\"2\",\"status\":\"waiting\",\"updated_at\":\"2021-08-06T18:51:58.000000Z\",\"created_at\":\"2021-08-06T18:51:58.000000Z\",\"id\":11}}',NULL,'2021-08-06 18:51:58','2021-08-06 18:51:58'),('5dcefab6-6105-4181-acbd-5460244b24c3','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"id\":10,\"zone_id\":2,\"product_id\":2,\"unit_id\":\"1\",\"variant\":\"\\u09ac\\u09dc\",\"required_qty\":6,\"sypplied_qty\":null,\"status\":\"waiting\",\"note\":null,\"created_at\":\"2021-08-06T18:50:14.000000Z\",\"updated_at\":\"2021-08-06T19:09:12.000000Z\"}}',NULL,'2021-08-06 19:09:13','2021-08-06 19:09:13'),('6809c145-01b9-441a-bee4-6bef708ec826','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":6}}',NULL,'2021-08-06 18:41:24','2021-08-06 18:41:24'),('8dee2df8-d6a8-4113-b2ce-4a7f1443f991','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',7,'{\"order\":{\"id\":5}}',NULL,'2021-08-06 16:53:47','2021-08-06 16:53:47'),('b34199cc-2d08-4f1f-be0f-12818fda7516','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"zone_id\":3,\"product_id\":3,\"unit_id\":1,\"variant\":\"\\u09ac\\u09dc\",\"required_qty\":\"232\",\"status\":\"waiting\",\"updated_at\":\"2021-08-06T18:43:17.000000Z\",\"created_at\":\"2021-08-06T18:43:17.000000Z\",\"id\":9}}',NULL,'2021-08-06 18:43:17','2021-08-06 18:43:17'),('d247f1b1-2524-442b-b698-d6b4c7e2e7e6','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":10}}',NULL,'2021-08-06 19:08:23','2021-08-06 19:08:23'),('d86a1f74-3695-448b-b07c-5f5eb40de11f','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"zone_id\":2,\"product_id\":2,\"unit_id\":1,\"variant\":\"\\u099b\\u09cb\\u099f\",\"required_qty\":\"23\",\"status\":\"waiting\",\"updated_at\":\"2021-08-06T18:42:46.000000Z\",\"created_at\":\"2021-08-06T18:42:46.000000Z\",\"id\":7}}',NULL,'2021-08-06 18:42:47','2021-08-06 18:42:47'),('e6a8dcff-c07e-4f21-a378-375753090af3','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":9}}',NULL,'2021-08-06 18:51:36','2021-08-06 18:51:36'),('e76e1e9a-8468-43c5-894f-1861852bc4c7','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',3,'{\"order\":{\"id\":11}}',NULL,'2021-08-06 19:10:51','2021-08-06 19:10:51'),('f1b0a0ff-c255-4929-ab4e-698baea3444a','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"id\":7,\"zone_id\":2,\"product_id\":2,\"unit_id\":\"1\",\"variant\":\"\\u099b\\u09cb\\u099f\",\"required_qty\":69,\"sypplied_qty\":null,\"status\":\"waiting\",\"note\":null,\"created_at\":\"2021-08-06T18:42:46.000000Z\",\"updated_at\":\"2021-08-06T19:08:57.000000Z\"}}',NULL,'2021-08-06 19:08:57','2021-08-06 19:08:57'),('f7b32d90-1eb8-497b-9d40-0d35838cc107','App\\Notifications\\orderSendToPurchaseTeamNotifications','App\\Models\\User',2,'{\"requirements\":{\"id\":7,\"zone_id\":2,\"product_id\":2,\"unit_id\":\"1\",\"variant\":\"\\u099b\\u09cb\\u099f\",\"required_qty\":71,\"sypplied_qty\":null,\"status\":\"waiting\",\"note\":null,\"created_at\":\"2021-08-06T18:42:46.000000Z\",\"updated_at\":\"2021-08-06T19:09:06.000000Z\"}}',NULL,'2021-08-06 19:09:06','2021-08-06 19:09:06'),('f8c4617f-236c-48f1-b846-7c91f4812f9c','App\\Notifications\\OrderCreateNotifications','App\\Models\\User',7,'{\"order\":{\"id\":7}}',NULL,'2021-08-06 18:42:15','2021-08-06 18:42:15');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_lists`
--

DROP TABLE IF EXISTS `order_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `variant` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_lists_order_id_foreign` (`order_id`),
  KEY `order_lists_unit_id_foreign` (`unit_id`),
  KEY `order_lists_product_id_foreign` (`product_id`),
  CONSTRAINT `order_lists_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_lists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `order_lists_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_lists`
--

LOCK TABLES `order_lists` WRITE;
/*!40000 ALTER TABLE `order_lists` DISABLE KEYS */;
INSERT INTO `order_lists` VALUES (1,3,1,2,'ছোট','23',NULL,'2021-08-06 14:43:21','2021-08-06 14:43:21'),(2,4,1,2,'ছোট','23',NULL,'2021-08-06 14:48:32','2021-08-06 14:48:32'),(3,4,1,3,'বড়','234',NULL,'2021-08-06 14:48:33','2021-08-06 14:48:33'),(4,5,1,2,'ছোট','23',NULL,'2021-08-06 16:53:47','2021-08-06 16:53:47'),(5,5,1,3,'বড়','2',NULL,'2021-08-06 16:53:48','2021-08-06 16:53:48'),(6,6,1,2,'ছোট','23',NULL,'2021-08-06 18:41:24','2021-08-06 18:41:24'),(7,7,1,3,'ছোট','23',NULL,'2021-08-06 18:42:16','2021-08-06 18:42:16'),(8,7,1,3,'বড়','232',NULL,'2021-08-06 18:42:17','2021-08-06 18:42:17'),(9,8,1,2,'বড়','3',NULL,'2021-08-06 18:49:46','2021-08-06 18:49:46'),(10,9,1,2,'ছোট','2',NULL,'2021-08-06 18:51:36','2021-08-06 18:51:36'),(11,10,1,2,'ছোট','23',NULL,'2021-08-06 19:08:23','2021-08-06 19:08:23'),(12,11,1,3,'ছোট','1',NULL,'2021-08-06 19:10:51','2021-08-06 19:10:51'),(13,11,1,3,'বড়','2',NULL,'2021-08-06 19:10:51','2021-08-06 19:10:51'),(14,11,1,3,'মাঝারি','3',NULL,'2021-08-06 19:10:52','2021-08-06 19:10:52');
/*!40000 ALTER TABLE `order_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `sales_executive_id` bigint unsigned NOT NULL,
  `customer_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_no_unique` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (3,1,1,'New-Customer','F_OR1188','pending','2021-08-06 14:43:21','2021-08-06 14:43:21'),(4,1,4,'New-Customer','F_OR4012','pending','2021-08-06 14:48:29','2021-08-06 17:07:37'),(5,2,6,'New-Customer','F_OR2036','pending','2021-08-06 16:53:46','2021-08-06 17:06:55'),(6,2,4,'New-Customer','F_OR8048','confirmed','2021-08-06 18:41:23','2021-08-06 19:04:01'),(7,3,6,'New-Customer','F_OR9030','pending','2021-08-06 18:42:15','2021-08-06 18:43:16'),(8,2,4,'New-Customer','F_OR3166','confirmed','2021-08-06 18:49:44','2021-08-06 19:09:12'),(9,3,4,'New-Customer','F_OR8861','confirmed','2021-08-06 18:51:36','2021-08-06 19:09:06'),(10,2,4,'New-Customer','F_OR3360','confirmed','2021-08-06 19:08:22','2021-08-06 19:08:57'),(11,2,4,'New-Customer','F_OR4950','confirmed','2021-08-06 19:10:51','2021-08-06 19:11:21');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packagings`
--

DROP TABLE IF EXISTS `packagings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packagings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_list_id` bigint unsigned NOT NULL,
  `pricing_barcode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pricing_status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packagings`
--

LOCK TABLES `packagings` WRITE;
/*!40000 ALTER TABLE `packagings` DISABLE KEYS */;
INSERT INTO `packagings` VALUES (1,1,'1188160803','102471',0,'2021-08-06 14:43:21','2021-08-06 14:43:21'),(2,2,'4012342679','189974',0,'2021-08-06 14:48:32','2021-08-06 14:48:32'),(3,3,'4012385061','794418',0,'2021-08-06 14:48:33','2021-08-06 14:48:33'),(4,4,'2036679333','105888',0,'2021-08-06 16:53:48','2021-08-06 16:53:48'),(5,5,'2036870463','699212',0,'2021-08-06 16:53:48','2021-08-06 16:53:48'),(6,6,'8048345003','379747',0,'2021-08-06 18:41:25','2021-08-06 18:41:25'),(7,7,'9030423958','770523',0,'2021-08-06 18:42:17','2021-08-06 18:42:17'),(8,8,'9030206508','388807',0,'2021-08-06 18:42:17','2021-08-06 18:42:17'),(9,9,'3166496129','483566',0,'2021-08-06 18:49:46','2021-08-06 18:49:46'),(10,10,'8861327958','436370',0,'2021-08-06 18:51:36','2021-08-06 18:51:36'),(11,11,'3360658730','362640',0,'2021-08-06 19:08:23','2021-08-06 19:08:23'),(12,12,'495067392','349922',0,'2021-08-06 19:10:51','2021-08-06 19:10:51'),(13,12,'4950612073','246634',0,'2021-08-06 19:10:52','2021-08-06 19:10:52'),(14,14,'4950210406','55336',0,'2021-08-06 19:10:52','2021-08-06 19:10:52');
/*!40000 ALTER TABLE `packagings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_histories`
--

DROP TABLE IF EXISTS `payment_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_account_log_id` bigint unsigned NOT NULL,
  `customer_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `payment_history` decimal(8,2) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_histories`
--

LOCK TABLES `payment_histories` WRITE;
/*!40000 ALTER TABLE `payment_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(125) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'order-create','web','2021-08-06 12:36:29','2021-08-06 12:36:29'),(2,'order-edit','web','2021-08-06 12:36:29','2021-08-06 12:36:29'),(3,'order-view','web','2021-08-06 12:36:30','2021-08-06 12:36:30'),(4,'order-delete','web','2021-08-06 12:36:31','2021-08-06 12:36:31'),(5,'order-status-update','web','2021-08-06 12:36:32','2021-08-06 12:36:32'),(6,'user-create','web','2021-08-06 12:36:32','2021-08-06 12:36:32'),(7,'user-edit','web','2021-08-06 12:36:32','2021-08-06 12:36:32'),(8,'user-status-update','web','2021-08-06 12:36:33','2021-08-06 12:36:33'),(9,'user-delete','web','2021-08-06 12:36:34','2021-08-06 12:36:34'),(10,'user-view','web','2021-08-06 12:36:35','2021-08-06 12:36:35'),(11,'user-show','web','2021-08-06 13:22:36','2021-08-06 13:22:36'),(12,'customer-create','web','2021-08-06 13:22:36','2021-08-06 13:22:36'),(13,'customer-edit','web','2021-08-06 13:22:36','2021-08-06 13:22:36'),(14,'customer-status-update','web','2021-08-06 13:22:38','2021-08-06 13:22:38'),(15,'customer-delete','web','2021-08-06 13:22:38','2021-08-06 13:22:38'),(16,'customer-view','web','2021-08-06 13:22:38','2021-08-06 13:22:38'),(17,'product-create','web','2021-08-06 13:22:38','2021-08-06 13:22:38'),(18,'product-edit','web','2021-08-06 13:22:38','2021-08-06 13:22:38'),(19,'product-status-update','web','2021-08-06 13:22:39','2021-08-06 13:22:39'),(20,'product-delete','web','2021-08-06 13:22:39','2021-08-06 13:22:39'),(21,'product-view','web','2021-08-06 13:22:39','2021-08-06 13:22:39'),(22,'supplier-create','web','2021-08-06 13:22:39','2021-08-06 13:22:39'),(23,'supplier-edit','web','2021-08-06 13:22:40','2021-08-06 13:22:40'),(24,'supplier-status-update','web','2021-08-06 13:22:40','2021-08-06 13:22:40'),(25,'supplier-delete','web','2021-08-06 13:22:41','2021-08-06 13:22:41'),(26,'supplier-view','web','2021-08-06 13:22:41','2021-08-06 13:22:41');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prices`
--

DROP TABLE IF EXISTS `prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_variant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prices`
--

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` VALUES (1,'1','BIG','F_PR0870',50.00,'2021-08-06 13:20:41','2021-08-06 13:20:41'),(2,'1','MEDIAM','F_PR0870',25.00,'2021-08-06 13:20:42','2021-08-06 13:20:42'),(3,'1','SMALL','F_PR0870',10.00,'2021-08-06 13:20:42','2021-08-06 13:20:42');
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `smg_manager_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sizes` text COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_smg_manager_id_foreign` (`smg_manager_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_unit_id_foreign` (`unit_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `products_smg_manager_id_foreign` FOREIGN KEY (`smg_manager_id`) REFERENCES `users` (`id`),
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,1,1,'Default Product','F_PR0870','[\"BIG\",\"SMALL\",\"MEDIAM\"]',NULL,1,'2021-08-06 14:11:13','2021-08-06 13:19:42','2021-08-06 14:11:13'),(2,4,3,1,'আম','F_PR9048','[\"\\u099b\\u09cb\\u099f\"]','null',0,NULL,'2021-08-06 14:07:45','2021-08-06 14:47:53'),(3,4,2,1,'আলু','F_PR1131','[\"\\u099b\\u09cb\\u099f\",\"\\u09ac\\u09dc\",\"\\u09ae\\u09be\\u099d\\u09be\\u09b0\\u09bf\"]',NULL,0,NULL,'2021-08-06 14:47:24','2021-08-06 14:47:24');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requirements`
--

DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requirements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `unit_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_qty` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sypplied_qty` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requirements_zone_id_foreign` (`zone_id`),
  KEY `requirements_product_id_foreign` (`product_id`),
  CONSTRAINT `requirements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `requirements_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requirements`
--

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
INSERT INTO `requirements` VALUES (7,2,2,'1','ছোট','71',NULL,'waiting',NULL,'2021-08-06 18:42:46','2021-08-06 19:09:06'),(8,3,3,'1','ছোট','23',NULL,'waiting',NULL,'2021-08-06 18:43:17','2021-08-06 18:43:17'),(9,3,3,'1','বড়','232',NULL,'waiting',NULL,'2021-08-06 18:43:17','2021-08-06 18:43:17'),(10,2,2,'1','বড়','6',NULL,'waiting',NULL,'2021-08-06 18:50:14','2021-08-06 19:09:12'),(12,2,3,'1','ছোট','1',NULL,'waiting',NULL,'2021-08-06 19:11:21','2021-08-06 19:11:21'),(13,2,3,'1','বড়','2',NULL,'waiting',NULL,'2021-08-06 19:11:21','2021-08-06 19:11:21'),(14,2,3,'1','মাঝারি','3',NULL,'waiting',NULL,'2021-08-06 19:11:21','2021-08-06 19:11:21');
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(5,3),(6,3),(7,3),(8,3),(9,3),(10,3),(12,3),(13,3),(14,3),(15,3),(16,3),(17,3),(18,3),(19,3),(20,3),(21,3),(22,3),(23,3),(24,3),(25,3),(26,3),(6,6),(7,6),(9,6),(10,6),(3,7),(5,7),(10,7),(22,7),(23,7),(24,7),(25,7),(26,7),(1,8),(2,8),(3,8),(4,8),(10,8),(12,8),(13,8),(15,8),(16,8),(17,8),(18,8),(20,8),(21,8);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(125) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','web','2021-08-06 12:36:23','2021-08-06 12:36:23'),(2,'admin','web','2021-08-06 12:36:25','2021-08-06 12:36:25'),(3,'smg_manager','web','2021-08-06 12:36:26','2021-08-06 12:36:26'),(4,'purchaser','web','2021-08-06 12:36:26','2021-08-06 12:36:26'),(5,'saler','web','2021-08-06 12:36:27','2021-08-06 12:36:27'),(6,'root_smg_manager','web','2021-08-06 13:22:35','2021-08-06 13:22:35'),(7,'purchases_team','web','2021-08-06 13:22:35','2021-08-06 13:22:35'),(8,'sales_executive','web','2021-08-06 13:22:36','2021-08-06 13:22:36');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_histories`
--

DROP TABLE IF EXISTS `supplier_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `purchase_team_id` bigint unsigned NOT NULL,
  `product_count` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_cost` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_histories`
--

LOCK TABLES `supplier_histories` WRITE;
/*!40000 ALTER TABLE `supplier_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_team_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_balance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `account_due` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `account_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `account_status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `total_requirements`
--

DROP TABLE IF EXISTS `total_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `total_requirements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `variant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_qty` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplied_qty` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `total_requirements_product_id_foreign` (`product_id`),
  KEY `total_requirements_unit_id_foreign` (`unit_id`),
  CONSTRAINT `total_requirements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `total_requirements_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `total_requirements`
--

LOCK TABLES `total_requirements` WRITE;
/*!40000 ALTER TABLE `total_requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `total_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `units_unit_unique` (`unit`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'Kg','2021-08-06 13:19:15','2021-08-06 13:19:15');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint unsigned NOT NULL,
  `added_by` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nid_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` tinyint NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,1,'Super-admin','superadmin@example.com','880179700000','$2y$10$cM.CzE.SZ5001NX4edn9S.kVQaf0yQCjFkqex4XPzLvPRKzAjBgy.',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2021-08-06 12:36:47','2021-08-06 12:36:47'),(2,1,1,'Root Smg Manager','rootsmgmanager@example.com','01797840514','$2y$10$46Ew6.Z7.9l4tLoMtMU9x.wcER6SryOzdo/Dbgv/AnykAVBk1X37O','dhanmondi-1',NULL,'Dhaka','dhaaka','user_19_Aug_19_33.jpg',NULL,1,NULL,NULL,'2021-08-06 13:24:33','2021-08-06 13:27:06'),(3,2,1,'Smg-manager','smgmanager@example.com','01797840511','$2y$10$zrmRmhC920zdAqiOh003wuxswAFJaIPEnHpYweMGqLZfI4IPfImfC','dhanmondi-1',NULL,'Dhaka','dhaaka','user_19_Aug_19_52.jpg',NULL,1,NULL,NULL,'2021-08-06 13:26:52','2021-08-06 13:27:00'),(4,2,1,'Sales-Executive-1','salesexecutive@example.com','01797840510','$2y$10$/V8Hhdyg31nm6Ynir95cDeupEJDd8ykKi0MBZ2gvCTU1aHx4ouKaa','dhanmondi-1',NULL,'Dhaka','dhaaka','user_19_Aug_19_05.jpg',NULL,1,NULL,NULL,'2021-08-06 13:28:05','2021-08-06 13:28:21'),(5,2,1,'Purchase-Team-1','purchaseteam@gmail.com','01797840512','$2y$10$voaT9E0FVYEaw3AMU3sRWO7q91RAvkY/H663kxjsM/eLXrkPueMmi','dhanmondi-1',NULL,'Dhaka','dhaaka','user_19_Aug_19_28.jpg',NULL,1,NULL,NULL,'2021-08-06 13:29:28','2021-08-06 13:29:41'),(6,3,1,'Sales-Executive-2','salesexecutive2@example.com','01797840519','$2y$10$kmTe3xusjqiqQFaL0altf.qHSCTPjKFPan41ePp4wuvnpztmDl1.i','dhanmondi-1',NULL,'Dhaka','dhaaka','user_22_Aug_22_19.jpg',NULL,1,NULL,NULL,'2021-08-06 16:46:19','2021-08-06 16:47:27'),(7,3,1,'Smg-Manager-2','smgmanager2@example.com','01797840516','$2y$10$i/st2Elk9ypfLc.knM3yDuxA9pLIRHEHrkXOGLEbjS9y3P/eNlOc6','dhanmondi-1',NULL,'Dhaka','dhaaka','user_22_Aug_22_28.png',NULL,1,NULL,NULL,'2021-08-06 16:51:28','2021-08-06 16:51:34');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zones`
--

DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones`
--

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES (1,'All-zone','2021-08-06 12:36:38','2021-08-06 12:36:38'),(2,'Mirpur-1','2021-08-06 13:25:42','2021-08-06 13:25:42'),(3,'Mirpur-2','2021-08-06 16:45:02','2021-08-06 16:45:02');
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-07 17:35:20
